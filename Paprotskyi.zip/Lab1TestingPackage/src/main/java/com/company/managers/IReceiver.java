package com.company.managers;

public interface IReceiver {
    void receiveMessage();
}
