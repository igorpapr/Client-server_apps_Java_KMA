package com.company.managers;

import java.net.InetAddress;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Sender {

    static BlockingQueue<byte[]> bq = new ArrayBlockingQueue<byte[]>(10);
    private InetAddress address;
    public Sender(byte[] mess) throws InterruptedException {
        bq.put(mess);
        // * * * (in next lab)
        //fake address now
        address = InetAddress.getLoopbackAddress();
    }

    public void send( InetAddress target) throws InterruptedException {
        byte[] mess = bq.take();
        System.out.println("Everything is OK, message array length: " + mess.length);
    }
}
