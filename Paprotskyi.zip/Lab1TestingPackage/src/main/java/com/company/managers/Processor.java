package com.company.managers;

import com.company.entities.GoodsStorage;
import com.company.entities.Message;
import com.company.utils.Encriptor;

public class Processor {

    public static GoodsStorage gs = new GoodsStorage();
    private boolean isOk;

    public Processor(){
    }

    public void process(Message message) {
        int command = message.getcType();
        synchronized (gs){
            try{
                //something herewith commands
            }catch (Exception e){

            }finally {
                notifyAll();
            }
        }
        Message m = new Message(command, message.getbUserId(),"OK");
        m.setToEncrypt(false);
        Encriptor.getInstance().encrypt(m.getBytes());
    }
}
